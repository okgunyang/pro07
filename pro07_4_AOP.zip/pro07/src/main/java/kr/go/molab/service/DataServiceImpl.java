package kr.go.molab.service;

public class DataServiceImpl {

}
