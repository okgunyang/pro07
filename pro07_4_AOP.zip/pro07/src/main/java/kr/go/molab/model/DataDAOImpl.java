package kr.go.molab.model;

public class DataDAOImpl {

}
