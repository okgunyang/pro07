package kr.go.molab.dto;

public class DataDTO {

}
