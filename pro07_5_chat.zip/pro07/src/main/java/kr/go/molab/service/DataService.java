package kr.go.molab.service;

public interface DataService {

}
