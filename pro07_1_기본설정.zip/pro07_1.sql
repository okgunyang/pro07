create database goverment;

use goverment;

create table sample(id varchar(20), pw varchar(20));

insert into sample values('kkt', '1234');
insert into sample values('kim', '1004');
insert into sample values('lee', '1111');
insert into sample values('cho', '2222');
insert into sample values('jeong', '3333');

commit;
