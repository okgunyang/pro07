package kr.go.molab.dto;

import lombok.Data;

@Data
public class SampleDTO {
	private String id;
	private String pw;
}