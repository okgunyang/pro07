package kr.go.molab.model;

public interface DataDAO {

}
